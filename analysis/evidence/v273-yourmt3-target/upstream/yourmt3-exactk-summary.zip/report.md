# YourMT3+ versus freeze_local_combo

Exploratory pretrained offline comparison; GuitarSet training overlap is not excluded.
This is not a validation under the baseline's causal latency constraints.

| True K | Rows | freeze exact | YourMT3+ exact | Under | Over | Net exact |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 39652 | 38035 (95.9220%) | 37836 (95.4202%) | 0 | 1816 | -199 |
| 1 | 12272 | 7889 (64.2846%) | 9464 (77.1186%) | 1816 | 992 | +1575 |
| 2 | 3445 | 1183 (34.3396%) | 1818 (52.7721%) | 982 | 645 | +635 |
| 3 | 2289 | 915 (39.9738%) | 1252 (54.6964%) | 661 | 376 | +337 |
| 4 | 1207 | 417 (34.5485%) | 725 (60.0663%) | 368 | 114 | +308 |
| 5 | 355 | 15 (4.2254%) | 189 (53.2394%) | 149 | 17 | +174 |
| 6 | 89 | 0 (0.0000%) | 44 (49.4382%) | 45 | 0 | +44 |

Global: freeze 48454/59309 (81.6976%), YourMT3+ 51328/59309 (86.5434%).
Corrections 5547; regressions 2673; net +2874.

Poly K2–K6: freeze 2530/7385 (34.2586%), YourMT3+ 4028/7385 (54.5430%).
Corrections 2430; regressions 932; net +1498.

K0 means no new assigned attack, not necessarily silence. Class 6 is capped at 6, as in the native target.
All decoded note events are counted, with no label-dependent instrument/pitch filter or offset tuning.
Raw notes, unmatched events, overflow counts, and row-level predictions are retained. No automatic promotion.
