# V27.3 — selector repair: legacy

Expérience sur folds 0/1/2/4 déjà exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Corrections | Régressions | Net |
|---|---:|---:|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | — | — | — |
| legacy | 81.6453% | 33.8389% | 479 | 510 | -31 |

| Vrai K | Référence | Variante | Corrections | Régressions | Net |
|---|---:|---:|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | 0 | 0 | +0 |
| K1 | 64.2846% | 64.2846% | 0 | 0 | +0 |
| K2 | 34.3396% | 34.8331% | 115 | 98 | +17 |
| K3 | 39.9738% | 34.2945% | 148 | 278 | -130 |
| K4 | 34.5485% | 33.8857% | 126 | 134 | -8 |
| K5 | 4.2254% | 25.3521% | 75 | 0 | +75 |
| K6 | 0.0000% | 16.8539% | 15 | 0 | +15 |

| Fold | Corrections | Régressions | Net |
|---|---:|---:|---:|
| 0 | 131 | 143 | -12 |
| 1 | 115 | 122 | -7 |
| 2 | 119 | 130 | -11 |
| 4 | 114 | 115 | -1 |

## Configuration

```json
{
  "H0": "fixed smoothed 0.84 posterior",
  "audit_producers_exclude_receiver": false,
  "batch_size": 192,
  "context_dimensions": 26,
  "context_names": [
    "birth__early_mass_fraction",
    "birth__frame_max",
    "birth__frame_mean",
    "birth__frame_std",
    "birth__late_mass_fraction",
    "birth__mid_mass_fraction",
    "birth__novel_mass",
    "birth__novel_track_fraction",
    "birth__positive_flow",
    "birth__positive_fraction",
    "birth__positive_track_concentration",
    "damping__early_mass_fraction",
    "damping__frame_max",
    "damping__frame_mean",
    "damping__frame_std",
    "damping__late_mass_fraction",
    "damping__lost_mass",
    "damping__mid_mass_fraction",
    "damping__negative_flow",
    "damping__sink_fraction",
    "damping__sink_track_concentration",
    "damping__vanishing_track_fraction",
    "persistence__mean_survival",
    "persistence__new_source_retention",
    "persistence__pre_post_retention",
    "persistence__retention_10"
  ],
  "eligible_rows": 7493,
  "epochs": 30,
  "fold3_used": false,
  "folds": [
    0,
    1,
    2,
    4
  ],
  "identical_epoch_budget": true,
  "learning_rate": 0.002,
  "native_rows": 59309,
  "objective": "legacy weighted action CE and three BCE losses",
  "one_probability_of_baseline_correctness": false,
  "output_destinations": [
    2,
    3,
    4,
    5,
    6
  ],
  "parameter_counts": [
    6596,
    6596,
    6596,
    6596
  ],
  "player05_used": false,
  "seed": 27402,
  "subset_descriptor_dimensions": 21,
  "width": 32
}
```

## Limites

- Development-exposed folds, not independent validation; no reference promotion.
- Only baseline-predicted K2/K3/K4 events have acoustic features; 1,918 poly errors remain outside the correction scope.
- K0/K1 are modeled as true classes by the coherent loss but remain forbidden output destinations for this experiment.
- H0 encodes the known fallback action; the original frozen network posterior is not available in these artifacts.
- The contracts arm bundles context, composition, fallback metadata and nested-producer repairs; it does not isolate each one.
- The coherent arm changes both the probability parameterization and loss; parameter counts are reported, not claimed equal.
- All sound observables remain fixed harmonic-template summaries with up to +160ms lookahead.
- No threshold or architecture choice is retuned using the outcomes of this run.
