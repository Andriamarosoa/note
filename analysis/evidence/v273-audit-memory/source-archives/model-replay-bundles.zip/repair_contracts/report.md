# V27.3 — selector repair: contracts

Expérience sur folds 0/1/2/4 déjà exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Corrections | Régressions | Net |
|---|---:|---:|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | — | — | — |
| contracts | 81.6605% | 33.9607% | 577 | 599 | -22 |

| Vrai K | Référence | Variante | Corrections | Régressions | Net |
|---|---:|---:|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | 0 | 0 | +0 |
| K1 | 64.2846% | 64.2846% | 0 | 0 | +0 |
| K2 | 34.3396% | 35.3846% | 157 | 121 | +36 |
| K3 | 39.9738% | 33.3333% | 177 | 329 | -152 |
| K4 | 34.5485% | 37.5311% | 185 | 149 | +36 |
| K5 | 4.2254% | 16.6197% | 44 | 0 | +44 |
| K6 | 0.0000% | 15.7303% | 14 | 0 | +14 |

| Fold | Corrections | Régressions | Net |
|---|---:|---:|---:|
| 0 | 130 | 140 | -10 |
| 1 | 154 | 156 | -2 |
| 2 | 112 | 134 | -22 |
| 4 | 181 | 169 | +12 |

## Configuration

```json
{
  "H0": "deterministic baseline-action encoding; correctness learned",
  "audit_producers_exclude_receiver": true,
  "batch_size": 192,
  "context_dimensions": 43,
  "context_names": [
    "birth__early_mass_fraction",
    "birth__frame_max",
    "birth__frame_mean",
    "birth__frame_std",
    "birth__late_mass_fraction",
    "birth__mid_mass_fraction",
    "birth__novel_mass",
    "birth__novel_track_fraction",
    "birth__positive_flow",
    "birth__positive_fraction",
    "birth__positive_track_concentration",
    "damping__early_mass_fraction",
    "damping__frame_max",
    "damping__frame_mean",
    "damping__frame_std",
    "damping__late_mass_fraction",
    "damping__lost_mass",
    "damping__mid_mass_fraction",
    "damping__negative_flow",
    "damping__sink_fraction",
    "damping__sink_track_concentration",
    "damping__vanishing_track_fraction",
    "persistence__mean_survival",
    "persistence__new_source_retention",
    "persistence__pre_post_retention",
    "persistence__retention_10",
    "persistence__retention_2",
    "persistence__retention_5",
    "persistence__stable_track_fraction",
    "spectral__active_late",
    "spectral__active_on",
    "spectral__active_pre",
    "spectral__dominant_late",
    "spectral__dominant_on",
    "spectral__dominant_pre",
    "spectral__entropy_late",
    "spectral__entropy_on",
    "spectral__entropy_pre",
    "spectral__late_pre_ratio",
    "spectral__mass_late",
    "spectral__mass_on",
    "spectral__mass_pre",
    "spectral__on_pre_ratio"
  ],
  "eligible_rows": 7493,
  "epochs": 30,
  "fold3_used": false,
  "folds": [
    0,
    1,
    2,
    4
  ],
  "identical_epoch_budget": true,
  "learning_rate": 0.002,
  "native_rows": 59309,
  "objective": "legacy weighted action CE and three BCE losses",
  "one_probability_of_baseline_correctness": false,
  "output_destinations": [
    2,
    3,
    4,
    5,
    6
  ],
  "parameter_counts": [
    8228,
    8228,
    8228,
    8228
  ],
  "player05_used": false,
  "seed": 27402,
  "subset_descriptor_dimensions": 21,
  "width": 32
}
```

## Limites

- Development-exposed folds, not independent validation; no reference promotion.
- Only baseline-predicted K2/K3/K4 events have acoustic features; 1,918 poly errors remain outside the correction scope.
- K0/K1 are modeled as true classes by the coherent loss but remain forbidden output destinations for this experiment.
- H0 encodes the known fallback action; the original frozen network posterior is not available in these artifacts.
- The contracts arm bundles context, composition, fallback metadata and nested-producer repairs; it does not isolate each one.
- The coherent arm changes both the probability parameterization and loss; parameter counts are reported, not claimed equal.
- All sound observables remain fixed harmonic-template summaries with up to +160ms lookahead.
- No threshold or architecture choice is retuned using the outcomes of this run.
