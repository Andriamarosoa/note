# V27.3 — group127 / direct

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| direct | 81.7380% | 34.5836% | +24 |

Corrections 686 ; régressions 662.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.8520% | +121 |
| K3 | 39.9738% | 38.7505% | -28 |
| K4 | 34.5485% | 27.4234% | -86 |
| K5 | 4.2254% | 9.0141% | +17 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +12 |
| 1 | +25 |
| 2 | -24 |
| 4 | +11 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +50.
Groupes sélectionnés par taille : {'1': 587, '2': 526, '3': 451, '4': 345, '5': 189, '6': 79, '7': 27}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 147, 'among_initially_wrong': 87, 'among_initially_correct': 60, 'selected_correct_joint_groups_with_all_members_wrong': 7}.
Gain annoncé : 496.830 ; observé : +24.
