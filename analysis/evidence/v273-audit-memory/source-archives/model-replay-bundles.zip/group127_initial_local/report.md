# V27.3 — group127 / local

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| local | 81.7886% | 34.9898% | +54 |

Corrections 640 ; régressions 586.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.7358% | +117 |
| K3 | 39.9738% | 38.6195% | -31 |
| K4 | 34.5485% | 30.6545% | -47 |
| K5 | 4.2254% | 8.4507% | +15 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +17 |
| 1 | +25 |
| 2 | -13 |
| 4 | +25 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +64.
Groupes sélectionnés par taille : {'1': 516, '2': 474, '3': 447, '4': 328, '5': 188, '6': 84, '7': 15}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 147, 'among_initially_wrong': 87, 'among_initially_correct': 60, 'selected_correct_joint_groups_with_all_members_wrong': 7}.
Gain annoncé : 473.273 ; observé : +54.
