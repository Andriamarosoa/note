# V27.3 — catalogue / control7

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| control7 | 81.7515% | 34.6919% | +32 |

Corrections 536 ; régressions 504.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.1843% | +98 |
| K3 | 39.9738% | 38.5321% | -33 |
| K4 | 34.5485% | 30.6545% | -47 |
| K5 | 4.2254% | 8.1690% | +14 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +18 |
| 1 | +20 |
| 2 | -6 |
| 4 | +0 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +35.
Groupes sélectionnés par taille : {'1': 1683, '2': 29, '3': 3, '4': 0, '5': 0, '6': 0, '7': 0}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 147, 'among_initially_wrong': 87, 'among_initially_correct': 60, 'selected_correct_joint_groups_with_all_members_wrong': 9}.
Gain annoncé : 364.123 ; observé : +32.
