# V27.3 — catalogue / control7

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| control7 | 81.7987% | 35.0711% | +60 |

Corrections 582 ; régressions 522.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.2714% | +101 |
| K3 | 39.9738% | 39.7117% | -6 |
| K4 | 34.5485% | 30.4060% | -50 |
| K5 | 4.2254% | 8.4507% | +15 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +16 |
| 1 | +23 |
| 2 | +1 |
| 4 | +20 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +61.
Groupes sélectionnés par taille : {'1': 1766, '2': 31, '3': 3, '4': 0, '5': 0, '6': 0, '7': 0}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 147, 'among_initially_wrong': 87, 'among_initially_correct': 60, 'selected_correct_joint_groups_with_all_members_wrong': 10}.
Gain annoncé : 383.195 ; observé : +60.
