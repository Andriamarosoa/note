# V27.3 — catalogue / corrector8

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| corrector8 | 81.7515% | 34.6919% | +32 |

Corrections 527 ; régressions 495.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 36.9811% | +91 |
| K3 | 39.9738% | 38.2700% | -39 |
| K4 | 34.5485% | 31.4002% | -38 |
| K5 | 4.2254% | 9.2958% | +18 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +13 |
| 1 | +11 |
| 2 | -4 |
| 4 | +12 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +35.
Groupes sélectionnés par taille : {'1': 1683, '2': 32, '3': 4, '4': 1, '5': 0, '6': 0, '7': 0, '8': 0}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 238, 'among_initially_wrong': 137, 'among_initially_correct': 101, 'selected_correct_joint_groups_with_all_members_wrong': 7}.
Gain annoncé : 354.450 ; observé : +32.
