# V27.3 — group127 / global

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| global | 81.7937% | 35.0305% | +57 |

Corrections 675 ; régressions 618.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.8229% | +120 |
| K3 | 39.9738% | 39.1874% | -18 |
| K4 | 34.5485% | 29.2461% | -64 |
| K5 | 4.2254% | 9.5775% | +19 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +18 |
| 1 | +26 |
| 2 | -20 |
| 4 | +33 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +68.
Groupes sélectionnés par taille : {'1': 554, '2': 515, '3': 442, '4': 338, '5': 188, '6': 77, '7': 27}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 147, 'among_initially_wrong': 87, 'among_initially_correct': 60, 'selected_correct_joint_groups_with_all_members_wrong': 6}.
Gain annoncé : 488.942 ; observé : +57.
