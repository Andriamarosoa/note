# V27.3 — catalogue / corrector8

Folds 0/1/2/4 exposés ; aucune validation indépendante ni promotion.

| Système | Exact-K global | Exact-K poly | Net face à freeze |
|---|---:|---:|---:|
| freeze_local_combo | 81.6976% | 34.2586% | 0 |
| coherent archivé | 81.7498% | 34.6784% | +31 |
| corrector8 | 81.7616% | 34.7732% | +38 |

Corrections 584 ; régressions 546.

| Vrai K | Référence | Variante | Net |
|---|---:|---:|---:|
| K0 | 95.9220% | 95.9220% | +0 |
| K1 | 64.2846% | 64.2846% | +0 |
| K2 | 34.3396% | 37.0682% | +94 |
| K3 | 39.9738% | 38.9253% | -24 |
| K4 | 34.5485% | 30.4888% | -49 |
| K5 | 4.2254% | 9.0141% | +17 |
| K6 | 0.0000% | 0.0000% | +0 |

| Fold | Net |
|---|---:|
| 0 | +19 |
| 1 | +4 |
| 2 | +4 |
| 4 | +11 |

Les résultats avec seulement les singletons réutilisent le même réseau entraîné sur tous les groupes ; ce ne sont pas des modèles réentraînés.

Net du décodage limité aux singletons : +39.
Groupes sélectionnés par taille : {'1': 1858, '2': 34, '3': 4, '4': 0, '5': 0, '6': 0, '7': 0, '8': 0}.
Synergies descriptives : {'events_with_correct_group_and_all_its_members_wrong': 238, 'among_initially_wrong': 137, 'among_initially_correct': 101, 'selected_correct_joint_groups_with_all_members_wrong': 9}.
Gain annoncé : 397.420 ; observé : +38.
